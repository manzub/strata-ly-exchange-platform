module.exports = {
  lintOnSave: false,
  publicPath: ''
}
