run npm install, then serve
